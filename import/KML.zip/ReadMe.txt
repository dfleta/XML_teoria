OGC(r) KML 2.2.0 - ReadMe.txt

OGC KML standard found in document OGC 07-147r2 at
 http://www.opengeospatial.org/standards/kml

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2008 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------

